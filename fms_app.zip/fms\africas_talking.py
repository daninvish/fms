"""Stub helper for Africa's Talking SMS integration (logs messages during development)."""
import os


def send_sms(to_number: str, message: str):
    # Placeholder: in production configure africa's talking SDK and credentials
    print(f"[AFRICA'S TALKING] To: {to_number} | Message: {message}")
    # Return a fake success response
    return {'status': 'sent', 'to': to_number}
