document.addEventListener('DOMContentLoaded', () => {
  const sidebar = document.querySelector('.sidebar');
  const menuButton = document.querySelector('[data-menu-toggle]');
  if (menuButton && sidebar) {
    menuButton.addEventListener('click', () => sidebar.classList.toggle('open'));
  }
  document.querySelectorAll('[data-auto-dismiss]').forEach((alert) => {
    window.setTimeout(() => alert.remove(), 4200);
  });
  document.querySelectorAll('[data-filter-table]').forEach((input) => {
    const table = document.querySelector(input.dataset.filterTable);
    if (!table) return;
    input.addEventListener('input', () => {
      const query = input.value.toLowerCase();
      table.querySelectorAll('tbody tr').forEach((row) => {
        row.hidden = !row.textContent.toLowerCase().includes(query);
      });
    });
  });
});
