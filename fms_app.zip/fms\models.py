from datetime import datetime
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, Float
from werkzeug.security import generate_password_hash, check_password_hash

Base = declarative_base()


class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    password_hash = Column(String(128), nullable=False)
    role = Column(String(30), default='staff')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    # Flask-Login attributes
    def is_active(self):
        return True

    def get_id(self):
        return str(self.id)

    def is_authenticated(self):
        return True


class Driver(Base):
    __tablename__ = 'drivers'
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    phone = Column(String(50))


class Vehicle(Base):
    __tablename__ = 'vehicles'
    id = Column(Integer, primary_key=True)
    registration = Column(String(50), unique=True, nullable=False)
    category = Column(String(50))
    make = Column(String(80))
    model = Column(String(80))
    odometer = Column(Integer, default=0)
    notes = Column(Text)


class Trip(Base):
    __tablename__ = 'trips'
    id = Column(Integer, primary_key=True)
    vehicle_id = Column(Integer, ForeignKey('vehicles.id'))
    driver_id = Column(Integer, ForeignKey('drivers.id'))
    origin = Column(String(200))
    destination = Column(String(200))
    distance_km = Column(Float, default=0.0)
    requested_by = Column(String(120))
    status = Column(String(50), default='requested')
    created_at = Column(DateTime, default=datetime.utcnow)


class FuelRecord(Base):
    __tablename__ = 'fuel_records'
    id = Column(Integer, primary_key=True)
    vehicle_id = Column(Integer, ForeignKey('vehicles.id'))
    litres = Column(Float)
    cost = Column(Float)
    recorded_at = Column(DateTime, default=datetime.utcnow)


class MaintenanceRecord(Base):
    __tablename__ = 'maintenance_records'
    id = Column(Integer, primary_key=True)
    vehicle_id = Column(Integer, ForeignKey('vehicles.id'))
    description = Column(Text)
    due_date = Column(DateTime)
    completed = Column(String(10), default='no')
    created_at = Column(DateTime, default=datetime.utcnow)
