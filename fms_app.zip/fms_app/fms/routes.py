import sqlite3
from flask import Blueprint, render_template, current_app, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required, current_user
from functools import wraps
from werkzeug.security import check_password_hash, generate_password_hash
from . import notifications
from . import log_user_action

from .forms import LoginForm, VehicleForm
from .forms import DriverForm, TripForm, FuelForm, MaintenanceForm

bp = Blueprint('main', __name__)


@bp.before_request
def record_page_visit():
    if not getattr(current_user, 'is_authenticated', False):
        return
    if request.endpoint in {'main.login', 'main.logout', 'main.index'}:
        return
    audit_user_action('page_view', f"Visited {request.path}", 'page', None)


def audit_user_action(action, details=None, entity_type=None, entity_id=None):
    if not getattr(current_user, 'is_authenticated', False):
        return
    log_user_action(
        user_id=getattr(current_user, 'id', None),
        username=getattr(current_user, 'username', None),
        action=action,
        details=details,
        entity_type=entity_type,
        entity_id=entity_id,
        ip_address=request.remote_addr,
        db_path=current_app.config['DATABASE_PATH'],
    )


def get_db():
    path = current_app.config['DATABASE_PATH']
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if getattr(current_user, 'role', None) != 'admin':
            flash('Administrator permission is required for this feature.', 'danger')
            return redirect(url_for('main.dashboard'))
        return view(*args, **kwargs)
    return wrapped


@bp.route('/')
def index():
    return render_template('index.html')


@bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE username = ?', (form.username.data,))
        row = c.fetchone()
        conn.close()
        if row and row['active'] and check_password_hash(row['password_hash'], form.password.data):
            # create lightweight user
            class U:
                def __init__(self, r):
                    self.id = r['id']
                    self.username = r['username']
                    self.role = r['role']
                    self.department = r['department'] if 'department' in r.keys() else ''
                    self.email = r['email'] if 'email' in r.keys() else ''
                    self.phone = r['phone'] if 'phone' in r.keys() else ''
                    self.active = r['active'] if 'active' in r.keys() else 1

                def get_id(self):
                    return str(self.id)

                def is_active(self):
                    return True

                def is_authenticated(self):
                    return True

            login_user(U(row))
            log_user_action(
                user_id=row['id'],
                username=row['username'],
                action='login',
                details='Successful login to dashboard',
                ip_address=request.remote_addr,
                db_path=current_app.config['DATABASE_PATH'],
            )
            return redirect(url_for('main.dashboard'))
        flash('Invalid credentials', 'danger')
    return render_template('login.html', form=form)


@bp.route('/logout')
def logout():
    if getattr(current_user, 'is_authenticated', False):
        log_user_action(
            user_id=getattr(current_user, 'id', None),
            username=getattr(current_user, 'username', None),
            action='logout',
            details='User signed out',
            ip_address=request.remote_addr,
            db_path=current_app.config['DATABASE_PATH'],
        )
    logout_user()
    return redirect(url_for('main.index'))


@bp.route('/dashboard')
@login_required
def dashboard():
    audit_user_action('view_dashboard', 'Viewed dashboard overview')
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT COUNT(*) as cnt FROM vehicles')
    vcount = c.fetchone()['cnt']
    c.execute('SELECT COUNT(*) as cnt FROM drivers')
    dcount = c.fetchone()['cnt']
    c.execute("SELECT COUNT(*) as cnt FROM trips WHERE status = 'requested'")
    trip_requests = c.fetchone()['cnt']
    c.execute("SELECT COUNT(*) as cnt FROM trips WHERE hod_status = 'approved' AND (dean_status IS NULL OR dean_status = 'pending' OR dean_status = '')")
    dean_queue = c.fetchone()['cnt']
    c.execute("SELECT COUNT(*) as cnt FROM maintenance_records WHERE completed != 'yes' AND due_date IS NOT NULL AND date(due_date) <= date('now', '+30 day')")
    maintenance_due = c.fetchone()['cnt']
    c.execute('SELECT COALESCE(SUM(cost), 0) as total FROM fuel_records')
    fuel_total = c.fetchone()['total']
    c.execute('''SELECT t.*, v.registration as vehicle_reg, d.name as driver_name
                 FROM trips t LEFT JOIN vehicles v ON v.id = t.vehicle_id
                 LEFT JOIN drivers d ON d.id = t.driver_id
                 ORDER BY t.id DESC LIMIT 5''')
    recent_trips = c.fetchall()
    conn.close()
    return render_template('dashboard.html', vcount=vcount, dcount=dcount,
                           trip_requests=trip_requests, dean_queue=dean_queue,
                           maintenance_due=maintenance_due, fuel_total=fuel_total,
                           recent_trips=recent_trips)


@bp.route('/vehicles')
@admin_required
def vehicles():
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT * FROM vehicles ORDER BY id')
    vehicles = c.fetchall()
    conn.close()
    return render_template('vehicles.html', vehicles=vehicles)


@bp.route('/vehicles/add', methods=['GET', 'POST'])
@admin_required
def add_vehicle():
    form = VehicleForm()
    if form.validate_on_submit():
        conn = get_db()
        c = conn.cursor()
        c.execute('INSERT INTO vehicles (registration, category, make, model, odometer, notes) VALUES (?, ?, ?, ?, ?, ?)',
                  (form.registration.data, form.category.data, form.make.data, form.model.data, form.odometer.data or 0, form.notes.data))
        conn.commit()
        conn.close()
        audit_user_action('add_vehicle', f"Added vehicle {form.registration.data}", 'vehicle', None)
        flash('Vehicle added', 'success')
        return redirect(url_for('main.vehicles'))
    return render_template('vehicle_form.html', form=form)


@bp.route('/drivers')
@admin_required
def drivers():
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT * FROM drivers ORDER BY id')
    drivers = c.fetchall()
    conn.close()
    return render_template('drivers.html', drivers=drivers)


@bp.route('/drivers/add', methods=['GET', 'POST'])
@admin_required
def add_driver():
    form = DriverForm()
    if form.validate_on_submit():
        conn = get_db()
        c = conn.cursor()
        c.execute('INSERT INTO drivers (name, phone) VALUES (?, ?)', (form.name.data, form.phone.data))
        conn.commit()
        conn.close()
        audit_user_action('add_driver', f"Added driver {form.name.data}", 'driver', None)
        flash('Driver added', 'success')
        return redirect(url_for('main.drivers'))
    return render_template('driver_form.html', form=form)


@bp.route('/trips')
@login_required
def trips():
    conn = get_db()
    c = conn.cursor()
    # filtering
    f = request.args.get('filter')
    base_q = '''SELECT t.*, v.registration as vehicle_reg, d.name as driver_name, d.phone as driver_phone FROM trips t
                 LEFT JOIN vehicles v ON v.id = t.vehicle_id
                 LEFT JOIN drivers d ON d.id = t.driver_id
              '''
    if f == 'pending_hod':
        q = base_q + " WHERE (t.hod_status IS NULL OR t.hod_status = 'pending' OR t.hod_status = '') ORDER BY t.id DESC"
        c.execute(q)
    elif f == 'pending_dean':
        q = base_q + " WHERE t.hod_status = 'approved' AND (t.dean_status IS NULL OR t.dean_status = 'pending' OR t.dean_status = '') ORDER BY t.id DESC"
        c.execute(q)
    else:
        q = base_q + ' ORDER BY t.id DESC'
        c.execute(q)
    trips = c.fetchall()
    conn.close()
    return render_template('trips.html', trips=trips)


@bp.route('/trips/add', methods=['GET', 'POST'])
@login_required
def add_trip():
    from .forms import TripForm
    form = TripForm()
    # populate choices
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT id, registration FROM vehicles ORDER BY registration')
    vehicles = c.fetchall()
    c.execute('SELECT id, name FROM drivers ORDER BY name')
    drivers = c.fetchall()
    conn.close()
    form.vehicle_id.choices = [(v['id'], v['registration']) for v in vehicles]
    form.driver_id.choices = [(d['id'], d['name']) for d in drivers]
    if form.validate_on_submit():
        conn = get_db()
        c = conn.cursor()
        c.execute('INSERT INTO trips (vehicle_id, driver_id, origin, destination, distance_km, requested_by, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime("now"))',
                  (form.vehicle_id.data, form.driver_id.data, form.origin.data, form.destination.data, form.distance_km.data or 0.0, form.requested_by.data, 'requested'))
        conn.commit()
        conn.close()
        audit_user_action('add_trip', f"Created trip request from {form.origin.data} to {form.destination.data}", 'trip', None)
        flash('Trip request created', 'success')
        return redirect(url_for('main.trips'))
    return render_template('trip_form.html', form=form)


def role_required(roles):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if getattr(current_user, 'role', None) not in roles:
                flash('You do not have permission to perform this action', 'danger')
                return redirect(url_for('main.trips'))
            return f(*args, **kwargs)
        return wrapped
    return decorator


@bp.route('/trips/<int:trip_id>/approve', methods=['POST'])
@login_required
def approve_trip(trip_id):
    action = request.form.get('action')  # 'approve' or 'reject'
    comment = request.form.get('comment')
    role = getattr(current_user, 'role', None)
    if role not in ('hod', 'dean', 'admin'):
        flash('Permission denied', 'danger')
        return redirect(url_for('main.trips'))

    conn = get_db()
    c = conn.cursor()
    # fetch current trip
    c.execute('SELECT * FROM trips WHERE id = ?', (trip_id,))
    trip = c.fetchone()
    if not trip:
        conn.close()
        flash('Trip not found', 'danger')
        return redirect(url_for('main.trips'))

    if role == 'hod':
        # HOD can approve/reject regardless
        new_status = 'approved' if action == 'approve' else 'rejected'
        c.execute('UPDATE trips SET hod_status = ?, hod_by = ?, hod_at = datetime("now") WHERE id = ?', (new_status, current_user.username, trip_id))
        # record audit
        c.execute('INSERT INTO approval_audit (trip_id, role, action, comment, by_user, at) VALUES (?, ?, ?, ?, ?, datetime("now"))',
              (trip_id, 'hod', new_status, comment, current_user.username))
        conn.commit()
        # send notifications
        notifications.notify_approval(trip, 'hod', new_status, current_user.username, comment)
        conn.close()
        audit_user_action('approve_trip', f"HOD {new_status} trip #{trip_id} with comment: {comment or 'No comment'}", 'trip', trip_id)
        flash(f'HOD {new_status}', 'success')
        return redirect(url_for('main.trips'))

    if role == 'dean':
        # Dean can only act after HOD approved
        if trip['hod_status'] != 'approved':
            conn.close()
            flash('Dean may only approve after HOD approval', 'warning')
            return redirect(url_for('main.trips'))
        new_status = 'approved' if action == 'approve' else 'rejected'
        c.execute('UPDATE trips SET dean_status = ?, dean_by = ?, dean_at = datetime("now") WHERE id = ?', (new_status, current_user.username, trip_id))
        c.execute('INSERT INTO approval_audit (trip_id, role, action, comment, by_user, at) VALUES (?, ?, ?, ?, ?, datetime("now"))',
              (trip_id, 'dean', new_status, comment, current_user.username))
        conn.commit()
        notifications.notify_approval(trip, 'dean', new_status, current_user.username, comment)
        conn.close()
        audit_user_action('approve_trip', f"Dean {new_status} trip #{trip_id} with comment: {comment or 'No comment'}", 'trip', trip_id)
        flash(f'Dean {new_status}', 'success')
        return redirect(url_for('main.trips'))

    # admin fallback
    if role == 'admin':
        new_status = 'approved' if action == 'approve' else 'rejected'
        c.execute('UPDATE trips SET hod_status = ?, hod_by = ?, hod_at = datetime("now"), dean_status = ?, dean_by = ?, dean_at = datetime("now") WHERE id = ?',
              (new_status, current_user.username, new_status, current_user.username, trip_id))
        c.execute('INSERT INTO approval_audit (trip_id, role, action, comment, by_user, at) VALUES (?, ?, ?, ?, ?, datetime("now"))',
              (trip_id, 'admin', new_status, comment, current_user.username))
        conn.commit()
        notifications.notify_approval(trip, 'admin', new_status, current_user.username, comment)
        conn.close()
        audit_user_action('approve_trip', f"Admin set trip #{trip_id} to {new_status} with comment: {comment or 'No comment'}", 'trip', trip_id)
        flash(f'Admin set approvals to {new_status}', 'success')
        return redirect(url_for('main.trips'))

    conn.close()
    flash('No action taken', 'warning')
    return redirect(url_for('main.trips'))


@bp.route('/fuel')
@admin_required
def fuel():
    conn = get_db()
    c = conn.cursor()
    c.execute('''SELECT f.*, v.registration as vehicle_reg FROM fuel_records f LEFT JOIN vehicles v ON v.id = f.vehicle_id ORDER BY f.id DESC''')
    records = c.fetchall()
    conn.close()
    return render_template('fuel.html', records=records)


@bp.route('/fuel/add', methods=['GET', 'POST'])
@admin_required
def add_fuel():
    from .forms import FuelForm
    form = FuelForm()
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT id, registration FROM vehicles ORDER BY registration')
    vehicles = c.fetchall()
    conn.close()
    form.vehicle_id.choices = [(v['id'], v['registration']) for v in vehicles]
    if form.validate_on_submit():
        conn = get_db()
        c = conn.cursor()
        c.execute('INSERT INTO fuel_records (vehicle_id, litres, cost, recorded_at) VALUES (?, ?, ?, datetime("now"))',
                  (form.vehicle_id.data, form.litres.data, form.cost.data or 0.0))
        conn.commit()
        conn.close()
        audit_user_action('add_fuel', f"Recorded fuel for vehicle ID {form.vehicle_id.data}: {form.litres.data} litres", 'fuel_record', None)
        flash('Fuel recorded', 'success')
        return redirect(url_for('main.fuel'))
    return render_template('fuel_form.html', form=form)


@bp.route('/maintenance')
@admin_required
def maintenance():
    conn = get_db()
    c = conn.cursor()
    c.execute('''SELECT m.*, v.registration as vehicle_reg FROM maintenance_records m LEFT JOIN vehicles v ON v.id = m.vehicle_id ORDER BY m.id DESC''')
    items = c.fetchall()
    conn.close()
    return render_template('maintenance.html', items=items)


@bp.route('/maintenance/add', methods=['GET', 'POST'])
@admin_required
def add_maintenance():
    from .forms import MaintenanceForm
    form = MaintenanceForm()
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT id, registration FROM vehicles ORDER BY registration')
    vehicles = c.fetchall()
    conn.close()
    form.vehicle_id.choices = [(v['id'], v['registration']) for v in vehicles]
    if form.validate_on_submit():
        conn = get_db()
        c = conn.cursor()
        c.execute('INSERT INTO maintenance_records (vehicle_id, description, due_date, completed, created_at) VALUES (?, ?, ?, ?, datetime("now"))',
                  (form.vehicle_id.data, form.description.data, form.due_date.data or None, 'no'))
        conn.commit()
        conn.close()
        audit_user_action('add_maintenance', f"Created maintenance record for vehicle ID {form.vehicle_id.data}", 'maintenance', None)
        flash('Maintenance record created', 'success')
        return redirect(url_for('main.maintenance'))
    return render_template('maintenance_form.html', form=form)


@bp.route('/reports')
@admin_required
def reports():
    conn = get_db()
    c = conn.cursor()
    # total vehicles
    c.execute('SELECT COUNT(*) as cnt FROM vehicles')
    total_vehicles = c.fetchone()['cnt']
    # total drivers
    c.execute('SELECT COUNT(*) as cnt FROM drivers')
    total_drivers = c.fetchone()['cnt']
    # fuel summary
    c.execute('SELECT SUM(litres) as litres, SUM(cost) as cost FROM fuel_records')
    fuel = c.fetchone()
    conn.close()
    return render_template('reports.html', total_vehicles=total_vehicles, total_drivers=total_drivers, fuel=fuel)


@bp.route('/activity-log')
@admin_required
def activity_log():
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT * FROM user_activity_log ORDER BY id DESC LIMIT 200')
    logs = c.fetchall()
    conn.close()
    return render_template('activity_log.html', logs=logs)


@bp.route('/users')
@admin_required
def users():
    conn = get_db()
    c = conn.cursor()
    department = request.args.get('department', '').strip()
    if department:
        c.execute('SELECT id, username, role, department, email, phone, active FROM users WHERE department = ? ORDER BY username', (department,))
    else:
        c.execute('SELECT id, username, role, department, email, phone, active FROM users ORDER BY department, username')
    us = c.fetchall()
    c.execute("SELECT DISTINCT department FROM users WHERE department IS NOT NULL AND department != '' ORDER BY department")
    departments = [row['department'] for row in c.fetchall()]
    conn.close()
    return render_template('users.html', users=us, departments=departments, selected_department=department)


@bp.route('/users/add', methods=['GET', 'POST'])
@admin_required
def add_user():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        role = request.form.get('role', 'staff')
        department = request.form.get('department', '').strip() or 'Transport Department'
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()
        allowed_roles = {'staff', 'hod', 'dean', 'admin'}
        if not username or len(password) < 6 or role not in allowed_roles:
            flash('Username, password of at least 6 characters, and a valid role are required.', 'danger')
            return render_template('user_form.html', user=None, form_data=request.form)
        conn = get_db()
        try:
            conn.execute('INSERT INTO users (username, password_hash, role, department, email, phone, active, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, datetime("now"))',
                         (username, generate_password_hash(password), role, department, email, phone))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            flash('That username already exists.', 'danger')
            return render_template('user_form.html', user=None, form_data=request.form)
        conn.close()
        audit_user_action('add_user', f"Created user {username} in {department}", 'user', None)
        flash(f'User {username} created for {department}.', 'success')
        return redirect(url_for('main.users'))
    return render_template('user_form.html', user=None, form_data={})


@bp.route('/users/edit/<int:user_id>', methods=['GET', 'POST'])
@admin_required
def edit_user(user_id):
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT id, username, role, department, email, phone, active FROM users WHERE id = ?', (user_id,))
    u = c.fetchone()
    if not u:
        conn.close()
        flash('User not found', 'danger')
        return redirect(url_for('main.users'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        role = request.form.get('role', 'staff')
        department = request.form.get('department', '').strip() or 'Transport Department'
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()
        active = 1 if request.form.get('active') == '1' else 0
        new_password = request.form.get('password', '')
        allowed_roles = {'staff', 'hod', 'dean', 'admin'}
        if not username or role not in allowed_roles:
            conn.close()
            flash('Username and a valid role are required.', 'danger')
            return render_template('user_form.html', user=u, form_data=request.form)
        if user_id == current_user.id and (active == 0 or role != 'admin'):
            conn.close()
            flash('You cannot deactivate or remove your own administrator access.', 'warning')
            return render_template('user_form.html', user=u, form_data=request.form)
        try:
            if new_password:
                if len(new_password) < 6:
                    conn.close()
                    flash('New passwords must be at least 6 characters.', 'danger')
                    return render_template('user_form.html', user=u, form_data=request.form)
                c.execute('UPDATE users SET username = ?, password_hash = ?, role = ?, department = ?, email = ?, phone = ?, active = ? WHERE id = ?',
                          (username, generate_password_hash(new_password), role, department, email, phone, active, user_id))
            else:
                c.execute('UPDATE users SET username = ?, role = ?, department = ?, email = ?, phone = ?, active = ? WHERE id = ?',
                          (username, role, department, email, phone, active, user_id))
        except sqlite3.IntegrityError:
            conn.close()
            flash('That username already exists.', 'danger')
            return render_template('user_form.html', user=u, form_data=request.form)
        conn.commit()
        conn.close()
        audit_user_action('edit_user', f"Updated user {username} (role: {role}, department: {department})", 'user', user_id)
        flash('User account updated.', 'success')
        return redirect(url_for('main.users'))
    conn.close()
    return render_template('user_form.html', user=u, form_data={})


@bp.route('/users/toggle/<int:user_id>', methods=['POST'])
@admin_required
def toggle_user(user_id):
    if user_id == current_user.id:
        flash('You cannot deactivate your own account.', 'warning')
        return redirect(url_for('main.users'))
    conn = get_db()
    c = conn.cursor()
    c.execute('UPDATE users SET active = CASE WHEN active = 1 THEN 0 ELSE 1 END WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()
    audit_user_action('toggle_user', f"Toggled user account status for user ID {user_id}", 'user', user_id)
    flash('User account status updated.', 'success')
    return redirect(url_for('main.users'))


@bp.route('/trips/<int:trip_id>/audit')
@login_required
def trip_audit(trip_id):
    conn = get_db()
    c = conn.cursor()
    c.execute('SELECT * FROM trips WHERE id = ?', (trip_id,))
    trip = c.fetchone()
    c.execute('SELECT * FROM approval_audit WHERE trip_id = ? ORDER BY id DESC', (trip_id,))
    audits = c.fetchall()
    conn.close()
    if not trip:
        flash('Trip not found', 'danger')
        return redirect(url_for('main.trips'))
    return render_template('approval_audit.html', trip=trip, audits=audits)



from jinja2 import pass_context

@pass_context
def date_time_format(context, dt_str=None):
    from datetime import datetime
    # If no argument provided, attempt to read current_user.last_login from the template context
    if dt_str is None:
        try:
            cu = context.get('current_user')
        except Exception:
            cu = None
        dt_candidate = getattr(cu, 'last_login', None) if cu is not None else None
        dt_str = dt_candidate
    # If still None, use current time
    if dt_str is None:
        dt = datetime.now()
        return dt.strftime('%d %b %Y %H:%M')
    # If passed a datetime object
    if isinstance(dt_str, datetime):
        dt = dt_str
    else:
        if not dt_str:
            return ''
        try:
            dt = datetime.strptime(dt_str, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            return str(dt_str)
    return dt.strftime('%d %b %Y %H:%M')

def welcome_message():
    from datetime import datetime
    now = datetime.now()
    hour = now.hour
    if 5 <= hour < 12:
        return "Good morning"
    elif 12 <= hour < 17:
        return "Good afternoon"
    elif 17 <= hour < 21:
        return "Good evening"
    else:
        return "Good night"