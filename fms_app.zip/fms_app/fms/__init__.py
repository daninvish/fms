import os
import sqlite3
from flask import Flask
from flask_login import LoginManager
from dotenv import load_dotenv

load_dotenv()

login_manager = LoginManager()


def ensure_db(path):
    conn = sqlite3.connect(path)
    c = conn.cursor()
    # minimal users and vehicles tables
    c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT DEFAULT 'staff',
        department TEXT DEFAULT 'Transport Department',
        email TEXT,
        phone TEXT,
        active INTEGER DEFAULT 1,
        created_at TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS vehicles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        registration TEXT UNIQUE NOT NULL,
        category TEXT,
        make TEXT,
        model TEXT,
        odometer INTEGER DEFAULT 0,
        notes TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS drivers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS trips (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehicle_id INTEGER,
        driver_id INTEGER,
        origin TEXT,
        destination TEXT,
        distance_km REAL DEFAULT 0.0,
        requested_by TEXT,
        status TEXT DEFAULT 'requested',
        hod_status TEXT DEFAULT 'pending',
        dean_status TEXT DEFAULT 'pending',
        hod_by TEXT,
        hod_at TEXT,
        dean_by TEXT,
        dean_at TEXT,
        created_at TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS fuel_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehicle_id INTEGER,
        litres REAL,
        cost REAL,
        recorded_at TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS maintenance_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehicle_id INTEGER,
        description TEXT,
        due_date TEXT,
        completed TEXT DEFAULT 'no',
        created_at TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS approval_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        trip_id INTEGER,
        role TEXT,
        action TEXT,
        comment TEXT,
        by_user TEXT,
        at TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS user_activity_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        action TEXT NOT NULL,
        details TEXT,
        entity_type TEXT,
        entity_id INTEGER,
        ip_address TEXT,
        created_at TEXT DEFAULT (datetime('now'))
    )
    ''')
    # Ensure legacy databases get new approval columns if missing
    def add_column_if_missing(table, column_def):
        # column_def example: 'hod_status TEXT DEFAULT "pending"'
        col_name = column_def.split()[0]
        c.execute(f"PRAGMA table_info('{table}')")
        cols = [r[1] for r in c.fetchall()]
        if col_name not in cols:
            try:
                c.execute(f"ALTER TABLE {table} ADD COLUMN {column_def}")
            except Exception:
                pass

    add_column_if_missing('trips', 'hod_status TEXT DEFAULT "pending"')
    add_column_if_missing('trips', 'dean_status TEXT DEFAULT "pending"')
    add_column_if_missing('trips', 'hod_by TEXT')
    add_column_if_missing('trips', 'hod_at TEXT')
    add_column_if_missing('trips', 'dean_by TEXT')
    add_column_if_missing('trips', 'dean_at TEXT')
    add_column_if_missing('users', 'department TEXT DEFAULT "Transport Department"')
    add_column_if_missing('users', 'email TEXT')
    add_column_if_missing('users', 'phone TEXT')
    add_column_if_missing('users', 'active INTEGER DEFAULT 1')
    add_column_if_missing('users', 'created_at TEXT')
    add_column_if_missing('user_activity_log', 'user_id INTEGER')
    add_column_if_missing('user_activity_log', 'username TEXT')
    add_column_if_missing('user_activity_log', 'action TEXT')
    add_column_if_missing('user_activity_log', 'details TEXT')
    add_column_if_missing('user_activity_log', 'entity_type TEXT')
    add_column_if_missing('user_activity_log', 'entity_id INTEGER')
    add_column_if_missing('user_activity_log', 'ip_address TEXT')
    add_column_if_missing('user_activity_log', 'created_at TEXT DEFAULT ""')
    conn.commit()
    conn.close()


def log_user_action(user_id=None, username=None, action=None, details=None, entity_type=None, entity_id=None, ip_address=None, db_path=None):
    if not action:
        return False
    if db_path is None:
        db_path = os.path.join(os.path.dirname(__file__), '..', 'fms.sqlite')

    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            '''
            INSERT INTO user_activity_log (user_id, username, action, details, entity_type, entity_id, ip_address, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
            ''',
            (user_id, username, action, details, entity_type, entity_id, ip_address),
        )
        conn.commit()
        return True
    finally:
        conn.close()


def create_app():
    app = Flask(__name__,
                template_folder=os.path.join(os.path.dirname(__file__), '..', 'templates'),
                static_folder=os.path.join(os.path.dirname(__file__), '..', 'static'))
    app.config['SECRET_KEY'] = os.environ.get('FMS_SECRET') or 'dev-secret'
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE', 'false').lower() == 'true'
    app.config['PERMANENT_SESSION_LIFETIME'] = 3600

    database_url = os.environ.get('DATABASE_URL')
    db_path = os.environ.get('FMS_DATABASE_PATH') or os.path.join(os.path.dirname(__file__), '..', 'fms.sqlite')
    app.config['DATABASE_PATH'] = db_path
    app.config['DATABASE_URL'] = database_url
    app.config['SERVER_NAME'] = os.environ.get('SERVER_NAME', '')

    ensure_db(db_path)

    login_manager.init_app(app)
    login_manager.login_view = 'main.login'

    @login_manager.user_loader
    def load_user(user_id):
        conn = sqlite3.connect(app.config['DATABASE_PATH'])
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE id = ?', (int(user_id),))
        row = c.fetchone()
        conn.close()
        if row:
            # lightweight user object
            class U:
                def __init__(self, r):
                    self.id = r['id']
                    self.username = r['username']
                    self.password_hash = r['password_hash']
                    self.role = r['role']
                    self.department = r['department'] if 'department' in r.keys() else ''
                    self.email = r['email'] if 'email' in r.keys() else ''
                    self.phone = r['phone'] if 'phone' in r.keys() else ''
                    self.active = r['active'] if 'active' in r.keys() else 1

                def get_id(self):
                    return str(self.id)

                def is_active(self):
                    return bool(self.active)

                def is_authenticated(self):
                    return True

            return U(row)
        return None

    from .routes import bp as main_bp, date_time_format, welcome_message
    app.register_blueprint(main_bp)
    app.jinja_env.globals.update({
        'date_time_format': date_time_format,
        'welcome_message': welcome_message,
    })

    return app
