import sys
sys.path.insert(0, r'c:\xampp\htdocs\Fleet_Management_System_Lira_University\fms_app')
from fms import notifications
print('notifications ok')
