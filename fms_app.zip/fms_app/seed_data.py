import os
import sqlite3
from werkzeug.security import generate_password_hash

DB = os.path.join(os.path.dirname(__file__), 'fms.sqlite')


def seed_samples():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    # vehicles
    v_samples = [
        ('LU-001', 'bus', 'Mercedes', 'Tourismo', 120000, 'Main bus'),
        ('LU-002', 'van', 'Toyota', 'Hiace', 80000, 'Faculty van'),
    ]
    for v in v_samples:
        try:
            c.execute('INSERT INTO vehicles (registration, category, make, model, odometer, notes) VALUES (?, ?, ?, ?, ?, ?)', v)
        except Exception:
            pass
    # drivers
    d_samples = [('John Doe', '0700000001'), ('Jane Okello', '0700000002')]
    for d in d_samples:
        try:
            c.execute('INSERT INTO drivers (name, phone) VALUES (?, ?)', d)
        except Exception:
            pass
    conn.commit()
    conn.close()
    print('Sample vehicles and drivers added')


if __name__ == '__main__':
    seed_samples()