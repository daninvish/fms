import os
import sqlite3
import tempfile
import unittest

from fms import ensure_db, log_user_action, create_app


class ActivityLoggingTests(unittest.TestCase):
    def setUp(self):
        workspace_root = os.path.abspath(os.path.dirname(__file__))
        self.db_dir = os.path.join(workspace_root, '.tmp_test_data')
        os.makedirs(self.db_dir, exist_ok=True)
        self.db_path = os.path.join(self.db_dir, 'fms_test.sqlite')
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        ensure_db(self.db_path)

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        if os.path.isdir(self.db_dir):
            os.rmdir(self.db_dir)

    def test_activity_log_table_is_created(self):
        conn = sqlite3.connect(self.db_path)
        tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall()
        conn.close()
        names = {row[0] for row in tables}
        self.assertIn('user_activity_log', names)

    def test_log_user_action_stores_action_details(self):
        log_user_action(
            user_id=7,
            username='alice',
            action='login',
            details='Successful login to dashboard',
            db_path=self.db_path,
        )

        conn = sqlite3.connect(self.db_path)
        row = conn.execute(
            "SELECT user_id, username, action, details FROM user_activity_log WHERE user_id = 7"
        ).fetchone()
        conn.close()

        self.assertIsNotNone(row)
        self.assertEqual(row[0], 7)
        self.assertEqual(row[1], 'alice')
        self.assertEqual(row[2], 'login')
        self.assertEqual(row[3], 'Successful login to dashboard')

    def test_dashboard_template_helpers_are_registered(self):
        app = create_app()
        with app.test_request_context('/'):
            class FakeUser:
                id = 1
                username = 'alice'
                role = 'admin'
                last_login = '2026-09-28 14:00:00'

            template = app.jinja_env.get_template('dashboard.html')
            rendered = template.render(
                current_user=FakeUser(),
                vcount=3,
                dcount=2,
                trip_requests=1,
                dean_queue=0,
                maintenance_due=1,
                fuel_total=125000,
                recent_trips=[],
            )
            self.assertIn('Good', rendered)
            self.assertIn('28 Sep 2026', rendered)


if __name__ == '__main__':
    unittest.main()
