# Deployment Guide

## Local development

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python run.py
```

Then open:

- http://localhost:5000
- or http://<your-lan-ip>:5000 from your phone on the same network

## Deploy to Render

1. Push the project to GitHub.
2. Log in to Render.
3. Create a new Web Service from the GitHub repo.
4. Use these values:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn run:app --bind 0.0.0.0:$PORT`
5. Set environment variables from `.env.example`.
6. Deploy.

## PostgreSQL support for public hosting

This app is currently compatible with SQLite for local testing. For public hosting, it is safer to move to PostgreSQL.

Recommended setup:

```bash
pip install psycopg2-binary
```

Then configure:

```env
DATABASE_URL=postgresql://user:password@host:5432/fms_db
SESSION_COOKIE_SECURE=true
FMS_SECRET=your-strong-secret
```

The app is already prepared to read `DATABASE_URL` and `FMS_DATABASE_PATH` from environment variables.

## Production hardening checklist

- use a strong `FMS_SECRET`
- enable HTTPS through your hosting provider
- set `SESSION_COOKIE_SECURE=true` in production
- keep `DEBUG=False`
- use a real database like PostgreSQL instead of SQLite in production
- rotate secrets regularly
- keep admin accounts limited to trusted users

## GitHub + Render quick flow

```bash
git init
git add .
git commit -m "Initial deployment setup"
git branch -M main
git remote add origin <your-github-url>
git push -u origin main
```

Then connect the GitHub repo to Render and deploy.
