# Lira University Fleet Management (Flask prototype)

This is a minimal Flask prototype of the Fleet Management System described in the project proposal. It uses SQLite and SQLAlchemy for simplicity.

Quick start:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python run.py
```

Open http://127.0.0.1:5000

Default admin not created — run `python seed.py` to create a default user.

## User administration

Sign in as an administrator and open **Users & roles**. Administrators can create accounts, assign `staff`, `hod`, `dean`, or `admin` roles, assign users to departments or faculties, update contact details and passwords, filter the directory by department, and activate or deactivate accounts. Inactive accounts cannot sign in.

The seeded development accounts are:

- `admin` / `adminpass`
- `hod` / `hodpass`
- `dean` / `deanpass`

app.run(host="0.0.0.0", port=5000, debug=True)
