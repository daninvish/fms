import os
import sqlite3
from werkzeug.security import generate_password_hash


DB = os.path.join(os.path.dirname(__file__), 'fms.sqlite')


def seed():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT
    )
    ''')
    conn.commit()
    c.execute('SELECT COUNT(*) FROM users')
    (count,) = c.fetchone()
    if count == 0:
        pwd = generate_password_hash('adminpass')
        c.execute('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)', ('admin', pwd, 'admin'))
        conn.commit()
        print('Created admin / adminpass')
    else:
        print('Users exist, skipping')
    conn.close()

    # Ensure HOD and Dean sample users
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'hod'")
    if c.fetchone()[0] == 0:
        c.execute('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)', ('hod', generate_password_hash('hodpass'), 'hod'))
        print('Created hod/hodpass')
    c.execute("SELECT COUNT(*) FROM users WHERE username = 'dean'")
    if c.fetchone()[0] == 0:
        c.execute('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)', ('dean', generate_password_hash('deanpass'), 'dean'))
        print('Created dean/deanpass')
    conn.commit()
    conn.close()


if __name__ == '__main__':
    seed()
