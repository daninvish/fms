document.addEventListener('DOMContentLoaded', () => {
  const sidebar = document.querySelector('.sidebar');
  const menuButton = document.querySelector('[data-menu-toggle]');
  const backdrop = document.querySelector('[data-sidebar-backdrop]');

  const setSidebarState = (isOpen) => {
    if (!sidebar) return;
    sidebar.classList.toggle('open', isOpen);
    if (backdrop) {
      backdrop.classList.toggle('visible', isOpen);
      backdrop.setAttribute('aria-hidden', String(!isOpen));
    }
    document.body.classList.toggle('sidebar-open', isOpen);
  };

  if (menuButton && sidebar) {
    menuButton.addEventListener('click', () => {
      const isOpen = !sidebar.classList.contains('open');
      setSidebarState(isOpen);
    });
  }

  if (backdrop) {
    backdrop.addEventListener('click', () => setSidebarState(false));
  }

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      setSidebarState(false);
    }
  });

  document.querySelectorAll('[data-auto-dismiss]').forEach((alert) => {
    window.setTimeout(() => alert.remove(), 4200);
  });

  document.querySelectorAll('[data-filter-table]').forEach((input) => {
    const table = document.querySelector(input.dataset.filterTable);
    if (!table) return;
    input.addEventListener('input', () => {
      const query = input.value.toLowerCase();
      table.querySelectorAll('tbody tr').forEach((row) => {
        row.hidden = !row.textContent.toLowerCase().includes(query);
      });
    });
  });
});
