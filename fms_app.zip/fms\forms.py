from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, FloatField, IntegerField, TextAreaField
from wtforms.validators import DataRequired, Length


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')


class VehicleForm(FlaskForm):
    registration = StringField('Registration', validators=[DataRequired(), Length(max=50)])
    category = SelectField('Category', choices=[('bus','Bus'),('minibus','Mini-bus'),('tractor','Tractor'),('van','Van'),('office','Office vehicle')])
    make = StringField('Make')
    model = StringField('Model')
    odometer = IntegerField('Odometer')
    notes = TextAreaField('Notes')
    submit = SubmitField('Save')


class DriverForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    phone = StringField('Phone')
    submit = SubmitField('Save')


class TripForm(FlaskForm):
    vehicle_id = SelectField('Vehicle', coerce=int, validators=[DataRequired()])
    driver_id = SelectField('Driver', coerce=int, validators=[DataRequired()])
    origin = StringField('Origin', validators=[DataRequired()])
    destination = StringField('Destination', validators=[DataRequired()])
    distance_km = FloatField('Distance (km)')
    requested_by = StringField('Requested By')
    submit = SubmitField('Create Request')


class FuelForm(FlaskForm):
    vehicle_id = SelectField('Vehicle', coerce=int, validators=[DataRequired()])
    litres = FloatField('Litres', validators=[DataRequired()])
    cost = FloatField('Cost')
    submit = SubmitField('Record Fuel')


class MaintenanceForm(FlaskForm):
    vehicle_id = SelectField('Vehicle', coerce=int, validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    due_date = StringField('Due Date (YYYY-MM-DD)')
    submit = SubmitField('Create')
