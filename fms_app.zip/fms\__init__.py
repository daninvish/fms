import os
import sqlite3
from flask import Flask
from flask_login import LoginManager

login_manager = LoginManager()


def ensure_db(path):
    conn = sqlite3.connect(path)
    c = conn.cursor()
    # minimal users and vehicles tables
    c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT DEFAULT 'staff',
        department TEXT DEFAULT 'Transport Department',
        email TEXT,
        phone TEXT,
        active INTEGER DEFAULT 1,
        created_at TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS vehicles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        registration TEXT UNIQUE NOT NULL,
        category TEXT,
        make TEXT,
        model TEXT,
        odometer INTEGER DEFAULT 0,
        notes TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS drivers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS trips (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehicle_id INTEGER,
        driver_id INTEGER,
        origin TEXT,
        destination TEXT,
        distance_km REAL DEFAULT 0.0,
        requested_by TEXT,
        status TEXT DEFAULT 'requested',
        hod_status TEXT DEFAULT 'pending',
        dean_status TEXT DEFAULT 'pending',
        hod_by TEXT,
        hod_at TEXT,
        dean_by TEXT,
        dean_at TEXT,
        created_at TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS fuel_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehicle_id INTEGER,
        litres REAL,
        cost REAL,
        recorded_at TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS maintenance_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vehicle_id INTEGER,
        description TEXT,
        due_date TEXT,
        completed TEXT DEFAULT 'no',
        created_at TEXT
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS approval_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        trip_id INTEGER,
        role TEXT,
        action TEXT,
        comment TEXT,
        by_user TEXT,
        at TEXT
    )
    ''')
    # Ensure legacy databases get new approval columns if missing
    def add_column_if_missing(table, column_def):
        # column_def example: 'hod_status TEXT DEFAULT "pending"'
        col_name = column_def.split()[0]
        c.execute(f"PRAGMA table_info('{table}')")
        cols = [r[1] for r in c.fetchall()]
        if col_name not in cols:
            try:
                c.execute(f"ALTER TABLE {table} ADD COLUMN {column_def}")
            except Exception:
                pass

    add_column_if_missing('trips', 'hod_status TEXT DEFAULT "pending"')
    add_column_if_missing('trips', 'dean_status TEXT DEFAULT "pending"')
    add_column_if_missing('trips', 'hod_by TEXT')
    add_column_if_missing('trips', 'hod_at TEXT')
    add_column_if_missing('trips', 'dean_by TEXT')
    add_column_if_missing('trips', 'dean_at TEXT')
    add_column_if_missing('users', 'department TEXT DEFAULT "Transport Department"')
    add_column_if_missing('users', 'email TEXT')
    add_column_if_missing('users', 'phone TEXT')
    add_column_if_missing('users', 'active INTEGER DEFAULT 1')
    add_column_if_missing('users', 'created_at TEXT')
    conn.commit()
    conn.close()


def create_app():
    app = Flask(__name__,
                template_folder=os.path.join(os.path.dirname(__file__), '..', 'templates'),
                static_folder=os.path.join(os.path.dirname(__file__), '..', 'static'))
    app.config['SECRET_KEY'] = os.environ.get('FMS_SECRET', 'dev-secret')
    db_path = os.path.join(os.path.dirname(__file__), '..', 'fms.sqlite')
    app.config['DATABASE_PATH'] = db_path

    ensure_db(db_path)

    login_manager.init_app(app)
    login_manager.login_view = 'main.login'

    @login_manager.user_loader
    def load_user(user_id):
        conn = sqlite3.connect(app.config['DATABASE_PATH'])
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE id = ?', (int(user_id),))
        row = c.fetchone()
        conn.close()
        if row:
            # lightweight user object
            class U:
                def __init__(self, r):
                    self.id = r['id']
                    self.username = r['username']
                    self.password_hash = r['password_hash']
                    self.role = r['role']
                    self.department = r['department'] if 'department' in r.keys() else ''
                    self.email = r['email'] if 'email' in r.keys() else ''
                    self.phone = r['phone'] if 'phone' in r.keys() else ''
                    self.active = r['active'] if 'active' in r.keys() else 1

                def get_id(self):
                    return str(self.id)

                def is_active(self):
                    return bool(self.active)

                def is_authenticated(self):
                    return True

            return U(row)
        return None

    from .routes import bp as main_bp
    app.register_blueprint(main_bp)

    return app
