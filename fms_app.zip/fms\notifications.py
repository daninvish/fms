import os
from .africas_talking import send_sms

def send_email(to_address: str, subject: str, body: str):
    # Simple development stub — prints to console. Configure SMTP here for production.
    print(f"[EMAIL] To: {to_address} | Subject: {subject}\n{body}")
    return {'status': 'sent'}


def notify_approval(trip, role, action, by_user, comment=None):
    # trip is a sqlite Row-like mapping (sqlite3.Row doesn't implement .get)
    trip_id = trip['id'] if 'id' in trip.keys() else None
    vehicle_reg = trip['vehicle_reg'] if 'vehicle_reg' in trip.keys() else ''
    msg = f"Trip {trip_id} ({vehicle_reg}) {action} by {role} ({by_user})."
    if comment:
        msg += f" Comment: {comment}"
    # try SMS to driver if phone known
    driver_phone = trip['driver_phone'] if 'driver_phone' in trip.keys() else None
    if driver_phone:
        send_sms(driver_phone, msg)
    # send admin email stub (configure real email in production)
    send_email('transport@lirauniversity.ac.ug', f'Trip {trip["id"]} {action}', msg)
    return True
